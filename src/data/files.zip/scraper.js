/**
 * TANZANIA GOVERNMENT DATA SCRAPER
 * Collects officials data from official government websites
 * 
 * Installation: npm install axios cheerio dotenv
 * 
 * Usage:
 *   node scraper.js --all           # Scrape all sources
 *   node scraper.js --regions       # Scrape regional commissioners only
 *   node scraper.js --districts     # Scrape district commissioners only
 *   node scraper.js --ministries    # Scrape cabinet ministers only
 */

const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');

class TanzaniaGovernmentScraper {
  constructor() {
    this.timeout = 10000;
    this.headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    };
    this.data = {
      regions: [],
      districts: [],
      ministries: [],
      metadata: {
        scrapedAt: new Date().toISOString(),
        sources: []
      }
    };
  }

  /**
   * Fetch and parse webpage with error handling
   */
  async fetchPage(url) {
    try {
      console.log(`  Fetching: ${url}`);
      const response = await axios.get(url, {
        headers: this.headers,
        timeout: this.timeout
      });
      return cheerio.load(response.data);
    } catch (error) {
      console.error(`  ✗ Error fetching ${url}:`, error.message);
      return null;
    }
  }

  /**
   * SCRAPER 1: Regional Commissioners
   * Source: Ministry of Interior - www.interior.go.tz
   */
  async scrapeRegionalCommissioners() {
    console.log('\n=== SCRAPING REGIONAL COMMISSIONERS ===');
    
    const sources = [
      'https://www.interior.go.tz/regions',
      'https://www.interior.go.tz/regional-commissioners',
      'https://www.tanzania.go.tz/government/regions'
    ];

    for (const source of sources) {
      const $ = await this.fetchPage(source);
      if (!$) continue;

      // Parse regional commissioners table/list
      // Note: Actual selectors depend on website structure
      // This is a template - adjust selectors based on actual HTML
      
      $('table tbody tr, .region-item, [data-region-commissioner]').each((i, elem) => {
        const name = $(elem).find('.name, .commissioner-name, td:nth-child(2)').text().trim();
        const email = $(elem).find('.email, [type="email"]').text().trim();
        const phone = $(elem).find('.phone, [type="tel"]').text().trim();
        const region = $(elem).find('.region, td:first-child').text().trim();

        if (name && region) {
          this.data.regions.push({
            name: region,
            commissioner: {
              fullName: name,
              email: email || null,
              phone: phone || null
            },
            dataSource: source
          });
        }
      });

      if (this.data.regions.length > 0) {
        this.data.metadata.sources.push(source);
        break;
      }
    }

    console.log(`  ✓ Scraped: ${this.data.regions.length} regions`);
  }

  /**
   * SCRAPER 2: District Commissioners
   * Source: Ministry of Interior - www.interior.go.tz/districts
   */
  async scrapeDistrictCommissioners() {
    console.log('\n=== SCRAPING DISTRICT COMMISSIONERS ===');
    
    const sources = [
      'https://www.interior.go.tz/districts',
      'https://www.interior.go.tz/district-commissioners',
      'https://www.tanzania.go.tz/districts'
    ];

    for (const source of sources) {
      const $ = await this.fetchPage(source);
      if (!$) continue;

      // Parse districts table/list
      // Note: Actual selectors depend on website structure
      
      $('table tbody tr, .district-item, [data-district-commissioner]').each((i, elem) => {
        const name = $(elem).find('.name, .commissioner-name, td:nth-child(2)').text().trim();
        const email = $(elem).find('.email, [type="email"]').text().trim();
        const phone = $(elem).find('.phone, [type="tel"]').text().trim();
        const district = $(elem).find('.district, td:first-child').text().trim();
        const region = $(elem).find('.region, td:nth-child(3)').text().trim();

        if (name && district) {
          this.data.districts.push({
            name: district,
            region: region || null,
            commissioner: {
              fullName: name,
              email: email || null,
              phone: phone || null
            },
            dataSource: source
          });
        }
      });

      if (this.data.districts.length > 0) {
        this.data.metadata.sources.push(source);
        break;
      }
    }

    console.log(`  ✓ Scraped: ${this.data.districts.length} districts`);
  }

  /**
   * SCRAPER 3: Cabinet Ministers & Deputies
   * Source: President's Office - www.statehouse.go.tz
   */
  async scrapeCabinetMinisters() {
    console.log('\n=== SCRAPING CABINET MINISTERS ===');
    
    const sources = [
      'https://www.statehouse.go.tz/government/cabinet',
      'https://www.statehouse.go.tz/cabinet-ministers',
      'https://www.tanzania.go.tz/government/ministries'
    ];

    for (const source of sources) {
      const $ = await this.fetchPage(source);
      if (!$) continue;

      // Parse cabinet structure
      // Note: May need to scrape individual ministry pages
      
      $('table tbody tr, .ministry-item, [data-ministry]').each((i, elem) => {
        const ministryName = $(elem).find('.ministry-name, td:first-child').text().trim();
        const ministerName = $(elem).find('.minister-name, td:nth-child(2)').text().trim();
        const ministerEmail = $(elem).find('.minister-email, [data-email]').text().trim();
        const ministerPhone = $(elem).find('.minister-phone, [data-phone]').text().trim();

        if (ministerName && ministryName) {
          const ministry = {
            name: ministryName,
            minister: {
              fullName: ministerName,
              email: ministerEmail || null,
              phone: ministerPhone || null
            },
            permanentSecretary: null,
            deputies: [],
            dataSource: source
          };

          this.data.ministries.push(ministry);
        }
      });

      if (this.data.ministries.length > 0) {
        this.data.metadata.sources.push(source);
        break;
      }
    }

    console.log(`  ✓ Scraped: ${this.data.ministries.length} ministries`);
    
    // Fetch individual ministry pages for detailed info
    await this.scrapeMinistryDetails();
  }

  /**
   * Scrape individual ministry websites for deputy ministers and permanent secretaries
   */
  async scrapeMinistryDetails() {
    console.log('\n=== SCRAPING MINISTRY DETAILS ===');
    
    // Common ministry website patterns
    const ministries = [
      { name: 'Ministry of Defence', domain: 'defence' },
      { name: 'Ministry of Health', domain: 'health' },
      { name: 'Ministry of Education', domain: 'education' },
      { name: 'Ministry of Finance', domain: 'finance' },
      // ... add all 70 ministries
    ];

    for (const ministry of ministries) {
      const url = `https://www.${ministry.domain}.go.tz/leadership`;
      const $ = await this.fetchPage(url);
      if (!$) continue;

      // Parse permanent secretary and deputies
      const psName = $('.permanent-secretary, [data-ps-name]').text().trim();
      const psEmail = $('.ps-email, [data-ps-email]').text().trim();
      const psPhone = $('.ps-phone, [data-ps-phone]').text().trim();

      const ministryData = this.data.ministries.find(m => m.name === ministry.name);
      if (ministryData) {
        ministryData.permanentSecretary = {
          fullName: psName || null,
          email: psEmail || null,
          phone: psPhone || null
        };

        // Parse deputy ministers
        $('table tbody tr, .deputy-minister, [data-deputy]').each((i, elem) => {
          const deputyName = $(elem).find('.name, td:first-child').text().trim();
          const deputyEmail = $(elem).find('.email').text().trim();
          const deputyPhone = $(elem).find('.phone').text().trim();
          const portfolio = $(elem).find('.portfolio, td:nth-child(2)').text().trim();

          if (deputyName) {
            ministryData.deputies.push({
              fullName: deputyName,
              portfolio: portfolio || null,
              email: deputyEmail || null,
              phone: deputyPhone || null
            });
          }
        });
      }
    }

    console.log('  ✓ Scraped ministry details');
  }

  /**
   * Run all scrapers
   */
  async scrapeAll() {
    console.log('Starting Tanzania Government Data Scraper...');
    console.log('Timestamp:', new Date().toISOString());
    
    await this.scrapeRegionalCommissioners();
    await this.scrapeDistrictCommissioners();
    await this.scrapeCabinetMinisters();
    
    return this.data;
  }

  /**
   * Save scraped data to file
   */
  saveData(filename = 'government-data-raw.json') {
    fs.writeFileSync(filename, JSON.stringify(this.data, null, 2));
    console.log(`\n✓ Data saved to: ${filename}`);
    console.log(`  Regions: ${this.data.regions.length}`);
    console.log(`  Districts: ${this.data.districts.length}`);
    console.log(`  Ministries: ${this.data.ministries.length}`);
  }
}

// Main execution
(async () => {
  const scraper = new TanzaniaGovernmentScraper();
  const scrapedData = await scraper.scrapeAll();
  scraper.saveData();
})();

module.exports = TanzaniaGovernmentScraper;
