# TANZANIA GOVERNMENT DATA RECONCILIATION SYSTEM

## Project Overview

This system reconciles and validates Tanzania's government organizational structure to ensure data consistency across:
- **31 Regions** with Regional Commissioners (1:1 mapping)
- **104 Districts** with District Commissioners (1:1 mapping)
- **70 Ministries** with Ministers, Deputy Ministers, and Permanent Secretaries (1:N mapping)

## Problem Statement

The current government data has significant discrepancies:
- ❌ Missing Regional Commissioners for some regions
- ❌ Districts not assigned to parent regions
- ❌ Missing Deputy Ministers and Permanent Secretaries
- ❌ Duplicate or conflicting official records
- ❌ Incomplete contact information (emails, phones)
- ❌ Officials holding multiple conflicting positions

## Solution Architecture

### Files Included

1. **tanzania-data-validator.js** - Main validation engine
   - Validates data integrity and completeness
   - Generates comprehensive reports
   - Detects duplicates and conflicts

2. **scraper.js** - Web scraper template
   - Collects data from official government websites
   - Handles multiple data sources
   - Formats data consistently

3. **government-data-sample.json** - Sample data structure
   - Shows expected JSON schema
   - Provides template for data entry

4. **Tanzania_Government_Data_Guide.docx** - Comprehensive guide
   - Detailed scraping instructions
   - Data validation rules
   - Official website sources
   - Troubleshooting guide

5. **README.md** - This file

## Installation & Setup

### Prerequisites
- Node.js v14+ (https://nodejs.org)
- npm (comes with Node.js)
- Internet access (for web scraping)

### Install Dependencies

```bash
# Install validation and scraping packages
npm install --save-dev

# Or individually:
npm install axios cheerio --save
```

## Quick Start

### 1. Scrape Government Data

```bash
node scraper.js
```

This will:
- Fetch data from official government websites
- Parse regional commissioners (31)
- Parse district commissioners (104)
- Parse cabinet ministers and deputies (70+)
- Save raw data to `government-data-raw.json`

### 2. Validate & Reconcile Data

```bash
node tanzania-data-validator.js
```

This will:
- Load raw data from `government-data-raw.json`
- Validate 31 regions ↔ 31 commissioners
- Validate 104 districts ↔ 104 commissioners
- Validate 70 ministries ↔ ministers ↔ deputies
- Check contact information completeness
- Detect duplicates and conflicts
- Generate detailed report: `validation-report.json`

### 3. Review Validation Report

```bash
cat validation-report.json
```

The report includes:
- ✅ Total errors found
- ⚠️ Warnings about incomplete data
- 📊 Statistics and metrics
- 🔴 Specific discrepancies to fix

## Data Structure

### Region Object
```json
{
  "regionId": "RG001",
  "name": "Arusha",
  "commissioner": {
    "fullName": "Name",
    "email": "commissioner@arusha.go.tz",
    "phone": "+255 784 123 456"
  }
}
```

### District Object
```json
{
  "districtId": "DS001",
  "name": "Arusha City",
  "region": "Arusha",
  "commissioner": {
    "fullName": "Name",
    "email": "commissioner@arusha-city.go.tz",
    "phone": "+255 784 234 567"
  }
}
```

### Ministry Object
```json
{
  "ministryId": "MIN001",
  "name": "Ministry of Defence",
  "minister": {
    "fullName": "Name",
    "email": "minister@defence.go.tz",
    "phone": "+255 784 111 111"
  },
  "permanentSecretary": {
    "fullName": "Name",
    "email": "ps@defence.go.tz",
    "phone": "+255 784 222 222"
  },
  "deputies": [
    {
      "fullName": "Deputy Name",
      "portfolio": "Operations",
      "email": "deputy@defence.go.tz"
    }
  ]
}
```

## Official Data Sources

### Primary Government Websites

| Source | URL | Data |
|--------|-----|------|
| President's Office | www.statehouse.go.tz | Cabinet Ministers |
| Ministry of Interior | www.interior.go.tz | Regional & District Commissioners |
| Ministry of Public Service | www.mopse.go.tz | Government Officials Database |
| National Portal | www.tanzania.go.tz | Government Structure |
| Individual Ministries | www.[name].go.tz | Ministry-specific details |

## Validation Rules

### Quantity Rules
```
✓ Regions: exactly 31
✓ Districts: exactly 104
✓ Ministries: exactly 70
✓ Regional Commissioners: 31 (one per region)
✓ District Commissioners: 104 (one per district)
✓ Ministers: 70 (one per ministry)
```

### Quality Rules
```
✓ All contacts must have email (@go.tz domain)
✓ All contacts must have phone (+255 format)
✓ No duplicate names
✓ No person holds multiple conflicting positions
✓ Every district belongs to exactly one region
```

### Hierarchical Rules
```
✓ All 31 regions must have 2-5 districts each
✓ Total districts must equal 104
✓ All officials organized by region/district/ministry
```

## Common Issues & Fixes

### Issue: Missing Regional Commissioners
**Solution:** Check regional office website directly or contact ministry

### Issue: District Not Assigned to Region
**Solution:** Cross-reference with official Interior Ministry list

### Issue: Official Holding Multiple Positions
**Solution:** Verify current position from latest official announcement

### Issue: Missing Contact Information
**Solution:** Call regional/ministry office or check official website

### Issue: Email Format Inconsistency
**Solution:** Standardize to @go.tz domain format

## Manual Data Entry Steps

If scraper fails for some officials:

1. **Access official website**
   - Visit region/ministry website directly
   - Look for "Leadership" or "Administration" section

2. **Extract information:**
   - Full name (must match official spelling)
   - Title/Position
   - Email address
   - Phone number
   - Date appointed

3. **Add to JSON:**
   - Match the data structure above
   - Maintain consistent formatting
   - Include data source URL

4. **Validate changes:**
   - Run validator again
   - Check validation-report.json
   - Verify no new conflicts created

## Troubleshooting

### Scraper Not Collecting Data
- Check internet connection
- Verify website URLs are current (may have changed)
- Check if websites require JavaScript rendering (need Puppeteer)
- Look at error messages for specific failures

### Validation Errors
- Review validation-report.json for specific issues
- Common problems:
  - Typos in region/district/ministry names
  - Missing contact information
  - Duplicate entries
  - Mismatched relationships

### Data Not Matching Between Tabs
- Verify spelling consistency (exact name matching)
- Check if official was recently transferred
- Confirm person data is not outdated
- Cross-reference with multiple official sources

## Generating Clean Final Dataset

Once validation is complete and all issues are fixed:

```bash
# Create final clean dataset
cp government-data-validated.json government-data-final.json

# The final dataset should have:
# - 0 validation errors
# - All 31 regions with commissioners
# - All 104 districts with commissioners and region assignments
# - All 70 ministries with ministers, PS, and deputies
# - All officials with complete contact information
```

## Data Export Formats

### JSON (Default)
```bash
# Already generated
government-data-final.json
```

### CSV Export
```bash
# Optional: Convert to CSV for spreadsheet use
node export-csv.js
```

### Excel Export
```bash
# Optional: Convert to Excel workbook
node export-xlsx.js
```

## API Usage

To use this data in your application:

```javascript
const validator = require('./tanzania-data-validator');
const TanzaniaGovernmentValidator = validator;

const v = new TanzaniaGovernmentValidator();
v.loadData('government-data-final.json');
const report = v.generateReport();

// Access data
console.log(report.statistics.regions);      // Region stats
console.log(report.statistics.districts);    // District stats
console.log(report.statistics.ministries);   // Ministry stats
```

## Reporting & Maintenance

### Generate Monthly Validation Report
```bash
node tanzania-data-validator.js > validation-$(date +%Y-%m-%d).txt
```

### Update Specific Official
1. Find in JSON
2. Update contact/position
3. Run validator
4. Confirm no new conflicts

### Archive Changes
```bash
cp government-data-final.json government-data-backup-$(date +%Y-%m-%d).json
```

## Performance Metrics

Expected results after full reconciliation:
- **Validation Time:** < 100ms
- **Data Size:** ~500 KB JSON
- **Completeness:** 100% (no missing records)
- **Accuracy:** 99%+ (verified against official sources)
- **Duplicates:** 0
- **Conflicts:** 0

## Support & Contribution

### Issues Found?
1. Document the specific discrepancy
2. Include source URL where you found correct info
3. Provide suggested correction

### Contributing Corrections
1. Update JSON with verified data
2. Include source URL in dataSource field
3. Run validator
4. Commit changes with explanation

## License

This system is designed for official Tanzania government data reconciliation. All data should be collected from official government sources only.

## Contact

For questions or issues with this system, contact the data reconciliation team.

---

**Last Updated:** 2024-01-15
**Version:** 1.0.0
**Status:** Active
