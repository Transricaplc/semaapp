/**
 * TANZANIA GOVERNMENT DATA RECONCILIATION SYSTEM
 * Validates and reconciles government structure data
 * Requirements:
 * - 31 regions must have exactly 31 regional commissioners
 * - 104 districts must have exactly 104 district commissioners
 * - 70 ministers must have corresponding deputy ministers and general secretaries
 */

const fs = require('fs');

class TanzaniaGovernmentValidator {
  constructor() {
    this.regions = [];
    this.districts = [];
    this.ministries = [];
    this.validationReport = {
      timestamp: new Date().toISOString(),
      errors: [],
      warnings: [],
      statistics: {},
      matches: {
        matched: 0,
        unmatched: 0,
        discrepancies: []
      }
    };
  }

  /**
   * VALIDATION RULE 1: Regions and Regional Commissioners
   * Rule: 31 regions = 31 regional commissioners (1:1 mapping)
   */
  validateRegionCommissioners() {
    console.log('\n=== VALIDATING REGION COMMISSIONERS ===');
    
    const regionCount = this.regions.length;
    const commissionerCount = this.regions.filter(r => r.commissioner && r.commissioner.name).length;
    
    if (regionCount !== 31) {
      this.validationReport.errors.push(
        `ERROR: Expected 31 regions, found ${regionCount}`
      );
    }
    
    if (commissionerCount !== regionCount) {
      this.validationReport.errors.push(
        `ERROR: Region Commissioner Mismatch - ${regionCount} regions but only ${commissionerCount} commissioners`
      );
      
      // Identify missing commissioners
      const missingCommissioners = this.regions
        .filter(r => !r.commissioner || !r.commissioner.name)
        .map(r => r.name);
      
      if (missingCommissioners.length > 0) {
        this.validationReport.warnings.push(
          `Missing commissioners for: ${missingCommissioners.join(', ')}`
        );
      }
    }
    
    this.validationReport.statistics.regions = {
      total: regionCount,
      withCommissioners: commissionerCount,
      missing: regionCount - commissionerCount
    };
  }

  /**
   * VALIDATION RULE 2: Districts and District Commissioners
   * Rule: 104 districts = 104 district commissioners (1:1 mapping)
   */
  validateDistrictCommissioners() {
    console.log('\n=== VALIDATING DISTRICT COMMISSIONERS ===');
    
    const districtCount = this.districts.length;
    const commissionerCount = this.districts.filter(d => d.commissioner && d.commissioner.name).length;
    
    if (districtCount !== 104) {
      this.validationReport.errors.push(
        `ERROR: Expected 104 districts, found ${districtCount}`
      );
    }
    
    if (commissionerCount !== districtCount) {
      this.validationReport.errors.push(
        `ERROR: District Commissioner Mismatch - ${districtCount} districts but only ${commissionerCount} commissioners`
      );
      
      // Identify missing commissioners
      const missingCommissioners = this.districts
        .filter(d => !d.commissioner || !d.commissioner.name)
        .map(d => d.name);
      
      if (missingCommissioners.length > 0) {
        this.validationReport.warnings.push(
          `Missing district commissioners for: ${missingCommissioners.slice(0, 10).join(', ')}... (${missingCommissioners.length} total)`
        );
      }
    }
    
    this.validationReport.statistics.districts = {
      total: districtCount,
      withCommissioners: commissionerCount,
      missing: districtCount - commissionerCount
    };
  }

  /**
   * VALIDATION RULE 3: Ministers and Deputy Ministers
   * Rule: Each ministry should have 1+ deputy minister
   * Expected: 70 ministers with corresponding deputy ministers
   */
  validateDeputyMinisters() {
    console.log('\n=== VALIDATING DEPUTY MINISTERS ===');
    
    const ministryCount = this.ministries.length;
    const withDeputies = this.ministries.filter(m => m.deputies && m.deputies.length > 0).length;
    const totalDeputies = this.ministries.reduce((sum, m) => sum + (m.deputies ? m.deputies.length : 0), 0);
    
    if (ministryCount !== 70) {
      this.validationReport.warnings.push(
        `Expected 70 ministries, found ${ministryCount}`
      );
    }
    
    if (withDeputies < ministryCount) {
      const missingDeputies = ministryCount - withDeputies;
      this.validationReport.errors.push(
        `ERROR: ${missingDeputies} ministries missing deputy ministers`
      );
    }
    
    this.validationReport.statistics.ministries = {
      total: ministryCount,
      withDeputies: withDeputies,
      totalDeputies: totalDeputies,
      averageDeputiesPerMinistry: (totalDeputies / ministryCount).toFixed(2),
      missing: ministryCount - withDeputies
    };
  }

  /**
   * VALIDATION RULE 4: General Secretaries
   * Each ministry should have a General Secretary/Permanent Secretary
   */
  validateGeneralSecretaries() {
    console.log('\n=== VALIDATING GENERAL SECRETARIES ===');
    
    const withGS = this.ministries.filter(m => m.generalSecretary && m.generalSecretary.name).length;
    const missing = this.ministries.length - withGS;
    
    if (missing > 0) {
      this.validationReport.errors.push(
        `ERROR: ${missing} ministries missing General Secretary/Permanent Secretary`
      );
    }
    
    this.validationReport.statistics.generalSecretaries = {
      assigned: withGS,
      missing: missing,
      percentage: ((withGS / this.ministries.length) * 100).toFixed(2) + '%'
    };
  }

  /**
   * DATA INTEGRITY CHECK: Contact Information Validation
   */
  validateContactInformation() {
    console.log('\n=== VALIDATING CONTACT INFORMATION ===');
    
    const missingPhones = [];
    const missingEmails = [];
    const missingAddresses = [];
    
    // Check regions
    this.regions.forEach(region => {
      if (region.commissioner) {
        if (!region.commissioner.phone) missingPhones.push(`${region.name} Commissioner`);
        if (!region.commissioner.email) missingEmails.push(`${region.name} Commissioner`);
      }
    });
    
    // Check districts
    this.districts.forEach(district => {
      if (district.commissioner) {
        if (!district.commissioner.phone) missingPhones.push(`${district.name} Commissioner`);
        if (!district.commissioner.email) missingEmails.push(`${district.name} Commissioner`);
      }
    });
    
    // Check ministries
    this.ministries.forEach(ministry => {
      if (ministry.minister) {
        if (!ministry.minister.phone) missingPhones.push(`${ministry.name} Minister`);
        if (!ministry.minister.email) missingEmails.push(`${ministry.name} Minister`);
      }
      if (ministry.generalSecretary) {
        if (!ministry.generalSecretary.phone) missingPhones.push(`${ministry.name} GS`);
        if (!ministry.generalSecretary.email) missingEmails.push(`${ministry.name} GS`);
      }
    });
    
    if (missingPhones.length > 0) {
      this.validationReport.warnings.push(
        `Missing phone numbers for ${missingPhones.length} officials`
      );
    }
    
    if (missingEmails.length > 0) {
      this.validationReport.warnings.push(
        `Missing email addresses for ${missingEmails.length} officials`
      );
    }
    
    this.validationReport.statistics.contactInfo = {
      officialsMissingPhones: missingPhones.length,
      officialsMissingEmails: missingEmails.length,
      missingDetails: { missingPhones, missingEmails }
    };
  }

  /**
   * HIERARCHICAL VALIDATION: Region → District relationships
   */
  validateRegionDistrictHierarchy() {
    console.log('\n=== VALIDATING REGION-DISTRICT HIERARCHY ===');
    
    const regionsByDistrict = {};
    
    this.districts.forEach(district => {
      if (!district.region) {
        this.validationReport.errors.push(`District "${district.name}" missing region assignment`);
      } else {
        if (!regionsByDistrict[district.region]) {
          regionsByDistrict[district.region] = [];
        }
        regionsByDistrict[district.region].push(district.name);
      }
    });
    
    // Verify all regions are represented
    this.regions.forEach(region => {
      if (!regionsByDistrict[region.name]) {
        this.validationReport.warnings.push(`Region "${region.name}" has no districts assigned`);
      }
    });
    
    this.validationReport.statistics.hierarchy = {
      regionsWithDistricts: Object.keys(regionsByDistrict).length,
      districtsAssignedToRegions: Object.values(regionsByDistrict).reduce((a, b) => a + b.length, 0)
    };
  }

  /**
   * DUPLICATE DETECTION
   */
  detectDuplicates() {
    console.log('\n=== DETECTING DUPLICATES ===');
    
    const checkDuplicates = (items, name) => {
      const seen = new Set();
      const duplicates = [];
      
      items.forEach(item => {
        if (seen.has(item.name)) {
          duplicates.push(item.name);
        }
        seen.add(item.name);
      });
      
      if (duplicates.length > 0) {
        this.validationReport.errors.push(
          `Duplicate ${name}: ${duplicates.join(', ')}`
        );
      }
      
      return duplicates;
    };
    
    const regionDups = checkDuplicates(this.regions, 'regions');
    const districtDups = checkDuplicates(this.districts, 'districts');
    const ministryDups = checkDuplicates(this.ministries, 'ministries');
    
    this.validationReport.statistics.duplicates = {
      regions: regionDups.length,
      districts: districtDups.length,
      ministries: ministryDups.length
    };
  }

  /**
   * PERSON MATCHING: Ensure officials appear only once (no conflicts)
   */
  detectPersonConflicts() {
    console.log('\n=== DETECTING PERSON CONFLICTS ===');
    
    const personMap = new Map();
    const conflicts = [];
    
    // Map all officials by name
    const addPerson = (name, position, organization) => {
      if (!name) return;
      
      const key = name.toLowerCase().trim();
      if (!personMap.has(key)) {
        personMap.set(key, []);
      }
      personMap.get(key).push({ position, organization });
    };
    
    this.regions.forEach(r => {
      if (r.commissioner) addPerson(r.commissioner.name, 'Regional Commissioner', r.name);
    });
    
    this.districts.forEach(d => {
      if (d.commissioner) addPerson(d.commissioner.name, 'District Commissioner', d.name);
    });
    
    this.ministries.forEach(m => {
      if (m.minister) addPerson(m.minister.name, 'Minister', m.name);
      if (m.generalSecretary) addPerson(m.generalSecretary.name, 'General Secretary', m.name);
      if (m.deputies) {
        m.deputies.forEach((d, i) => {
          addPerson(d.name, `Deputy Minister ${i + 1}`, m.name);
        });
      }
    });
    
    // Find conflicts (person with multiple different positions)
    personMap.forEach((positions, name) => {
      if (positions.length > 1) {
        const uniquePositions = new Set(positions.map(p => p.position));
        if (uniquePositions.size > 1) {
          conflicts.push({
            person: name,
            positions: positions
          });
        }
      }
    });
    
    if (conflicts.length > 0) {
      this.validationReport.errors.push(
        `CONFLICT: ${conflicts.length} officials holding multiple different positions`
      );
      this.validationReport.statistics.personConflicts = conflicts;
    }
  }

  /**
   * COMPREHENSIVE REPORT GENERATION
   */
  generateReport() {
    console.log('\n' + '='.repeat(60));
    console.log('TANZANIA GOVERNMENT DATA VALIDATION REPORT');
    console.log('='.repeat(60));
    
    this.validateRegionCommissioners();
    this.validateDistrictCommissioners();
    this.validateDeputyMinisters();
    this.validateGeneralSecretaries();
    this.validateContactInformation();
    this.validateRegionDistrictHierarchy();
    this.detectDuplicates();
    this.detectPersonConflicts();
    
    return this.validationReport;
  }

  /**
   * EXPORT REPORT TO FILE
   */
  exportReport(filename = 'validation-report.json') {
    const report = this.generateReport();
    fs.writeFileSync(filename, JSON.stringify(report, null, 2));
    
    console.log('\n' + '='.repeat(60));
    console.log('VALIDATION SUMMARY');
    console.log('='.repeat(60));
    console.log(`Total Errors: ${report.errors.length}`);
    console.log(`Total Warnings: ${report.warnings.length}`);
    console.log(`\nErrors:`);
    report.errors.forEach(e => console.log(`  ❌ ${e}`));
    console.log(`\nWarnings:`);
    report.warnings.forEach(w => console.log(`  ⚠️  ${w}`));
    console.log(`\nReport saved to: ${filename}`);
    
    return report;
  }

  /**
   * LOAD DATA FROM JSON
   */
  loadData(dataFile) {
    try {
      const data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
      this.regions = data.regions || [];
      this.districts = data.districts || [];
      this.ministries = data.ministries || [];
      console.log('✓ Data loaded successfully');
      console.log(`  Regions: ${this.regions.length}`);
      console.log(`  Districts: ${this.districts.length}`);
      console.log(`  Ministries: ${this.ministries.length}`);
    } catch (error) {
      console.error('Failed to load data:', error.message);
    }
  }
}

// EXAMPLE USAGE
if (require.main === module) {
  const validator = new TanzaniaGovernmentValidator();
  
  // Create sample data structure (to be replaced with actual scraped data)
  const sampleData = {
    regions: [
      {
        name: 'Arusha',
        commissioner: { name: 'John Doe', email: 'john@gov.tz', phone: '+255...' }
      },
      // ... 30 more regions
    ],
    districts: [
      {
        name: 'Arusha City',
        region: 'Arusha',
        commissioner: { name: 'Jane Smith', email: 'jane@gov.tz', phone: '+255...' }
      },
      // ... 103 more districts
    ],
    ministries: [
      {
        name: 'Ministry of Defence',
        minister: { name: 'Minister Name', email: 'minister@gov.tz', phone: '+255...' },
        generalSecretary: { name: 'GS Name', email: 'gs@gov.tz', phone: '+255...' },
        deputies: [
          { name: 'Deputy 1', email: 'deputy1@gov.tz', phone: '+255...' }
        ]
      },
      // ... 69 more ministries
    ]
  };
  
  validator.loadData('government-data.json'); // Load actual data when available
  const report = validator.exportReport('validation-report.json');
}

module.exports = TanzaniaGovernmentValidator;
